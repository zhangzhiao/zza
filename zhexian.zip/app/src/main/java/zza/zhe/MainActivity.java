package zza.zhe;

import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private HashMap<Double,Double> map;
    private  int totalvalue;
    private int pjvalue;
    private MyChartView.Mstyle mstyle;
    Button button1 ,button2;
    TextView textView1,textView2;
    MyChartView chartView;
    Handler handler;
    boolean key =true;
    private Runnable runnable;
    int count =10;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        byID();
         handler =new Handler(){
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
            }
        };
         button2.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 handler.post(runnable);
                 Toast.makeText(getApplicationContext(),"自动模式已经开启",Toast.LENGTH_SHORT).show();
                 key =true;
             }
         });
    }
    public  void byID(){
        totalvalue =30;
        pjvalue =2;
        button1=findViewById(R.id.shoudong);
        button2=findViewById(R.id.zidong);
        textView1=findViewById(R.id.zzaa);
        textView2=findViewById(R.id.i);
        chartView=findViewById(R.id.zza);
        map =new HashMap<>();
        map.put(0.0,0.0);
        chartView.SetTuView(map,totalvalue,pjvalue,"ms","°C",false);
        runnable =new Runnable() {
            @Override
            public void run() {
                getData();
button1.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        getData();
        key=false;
    }
});
if(key){
    handler.postDelayed(runnable,1000);
}
            }
        };
    }
    public void getData(){

        for(int a =1;a<30;a++)
        {
            String d =String.valueOf(a);
            String b =String.valueOf((a+2));
            textView1 .setText(d);
            textView2.setText(b);
            map.put(Double.parseDouble(textView1.getText().toString()),Double.parseDouble(textView2.getText().toString()));

            chartView.setMap(map);
            chartView.postInvalidate();
        }

    }

}
