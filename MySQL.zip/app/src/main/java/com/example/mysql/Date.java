package com.example.mysql;

public class Date  {
    String name;
    String ID;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public Date(String name, String ID, String money) {
        this.name = name;
        this.ID = ID;
        this.money = money;
    }

    String money;
}
