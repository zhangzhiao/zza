package com.example.mysql;

import android.content.Context;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;
import java.util.Locale;

public class MyBase extends BaseAdapter {
    Vibrator vibrator;
    List<Date> mlist;
    LayoutInflater winflater;
    TextToSpeech textToSpeech;
    Context the;


    public MyBase(Context context,List<Date> list){
        mlist=list;
        the=context;
        winflater=LayoutInflater.from(context);


    }

    @Override
    public int getCount() {
        return mlist.size();
    }

    @Override
    public Object getItem(int position) {
        return mlist.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHelper viewHelper=null;
        final Date date =mlist.get(position);
        if(convertView==null){
            viewHelper=new ViewHelper();
            convertView =winflater.inflate(R.layout.item,null);
            viewHelper.ID=convertView.findViewById(R.id.it_id);
            viewHelper.name=convertView.findViewById(R.id.it_name);
            viewHelper.money=convertView.findViewById(R.id.it_money);
            viewHelper.button=convertView.findViewById(R.id.bofang);
            convertView.setTag(viewHelper);
        }else{
            viewHelper=(ViewHelper) convertView.getTag();
        }

        viewHelper.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vibrator=(Vibrator)the.getSystemService(Context.VIBRATOR_SERVICE);
                textToSpeech=new TextToSpeech(the, new TextToSpeech.OnInitListener() {
                    @Override
                    public void onInit(int status) {
                        if(status==TextToSpeech.SUCCESS){
                            textToSpeech.setLanguage(Locale.ENGLISH);
                        }
                    }
                });
                Log.i("zza", "onClick: zasadasdas");
                vibrator.vibrate(3000);
                textToSpeech.speak("money"+date.getMoney(), TextToSpeech.QUEUE_ADD,null);
            }
        });
        viewHelper.name.setText(date.getName());
        viewHelper.money.setText(date.money);
        viewHelper.ID.setText(date.ID);

        return convertView;
    }

    class ViewHelper{
        public TextView name,ID,money;
        public Button button;
    }
}
