package com.example.mysql;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    Button button;
    MySQliteHelper helper;
    SQLiteDatabase db;
    List<Date> list;
    MyBase base;
    EditText editText, editTextid, editTextname, editTextvalues;
    ListView listView;
    TextToSpeech textToSpeech;
    Vibrator vibrator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        vibrator= (Vibrator) getApplicationContext().getSystemService(Context.VIBRATOR_SERVICE);
        helper = new MySQliteHelper(getApplicationContext());
        setContentView(R.layout.activity_main);
        db = helper.getWritableDatabase();
        button = findViewById(R.id.tianjia);
        editText = findViewById(R.id.editText);
        editTextid = findViewById(R.id.gai_id);
        editTextname = findViewById(R.id.gai_name);
        editTextvalues = findViewById(R.id.gai_values);
        listView=findViewById(R.id.list);

        button.setOnClickListener(new View.OnClickListener() {

            int count = 1;

            public void onClick(View v) {

                count += 1;
                ContentValues values = new ContentValues();
                values.put("username", "zza" + count);
                values.put("ID", count);
                values.put("money", count * 299);
                db.insert("za", null, values);
                Toast.makeText(getApplicationContext(), "添加成功", Toast.LENGTH_SHORT).show();

            }
        });
        findViewById(R.id.shanchu).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!editText.getText().toString().equals("")) {
                    String del = editText.getText().toString();
                    db.delete("za", "ID=" + del, null);
                    Toast.makeText(getApplicationContext(), "删除成功", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "您未输入条件", Toast.LENGTH_SHORT).show();
                }
            }
        });
        findViewById(R.id.xiugai).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!editTextid.getText().toString().equals("") && !editTextname.getText().toString().equals("") && !editTextvalues.getText().toString().equals("")) {
                    ContentValues contentValues = new ContentValues();
                    contentValues.put(editTextname.getText().toString(), editTextvalues.getText().toString());
                    db.update("za", contentValues, "ID=" + editTextid.getText().toString(), null);
                    Toast.makeText(getApplicationContext(), "修改成功", Toast.LENGTH_SHORT).show();
                }
            }
        });
        list = new ArrayList<Date>();
        findViewById(R.id.chauxn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor cursor =db.query("za",null,null,null,null,null,null);
                while(cursor.moveToNext()){
                    String name =cursor.getString(0);
                    String ID =cursor.getString(1);
                    String money=cursor.getString(2);
                    list.add(new Date(name,ID,money));
                }



            }
        });
        base =new MyBase(getApplicationContext(),list);
        listView.setAdapter(base);
    }



}