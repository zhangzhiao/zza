package com.example.http;

import android.app.Activity;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.JsonReader;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
private Button button;
private TextView textView;
private Handler handler =new Handler(){
    @Override
    public void handleMessage(Message msg) {
        super.handleMessage(msg);
        switch (msg.what){
            case 1:
                String zza=msg.obj.toString();
                textView.append("服务器消息："+zza+"\n");
                break;
        }

    }
};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView=findViewById(R.id.textView);
        button=findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            URL url = new URL("http://10.0.2.2:8080/Myservers/hello");
                            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                            connection.setRequestMethod("GET");
                            int resultCode = connection.getResponseCode();
                            if (resultCode == HttpURLConnection.HTTP_OK) {
                                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                byte[] buffer = new byte[1024];
                                InputStream is = connection.getInputStream();

                                int i = 0;
                                while ((i = is.read(buffer)) != -1) {
                                    baos.write(buffer, 0, i);
                                }
                                Log.d("zz", "response:" + baos.toString());
                                String json =baos.toString();
                                JSONObject jsonObject =new JSONObject(json);
                                String data1 =jsonObject.getString("name");
                                String data2 =jsonObject.getString("age");
                                String data3 =jsonObject.getString("sex");
                               String end ="name="+data1+"age="+data2+"sex="+data3;
                               Message message =new Message();
                               message.obj=end;
                               message.what=1;
                               handler.sendMessage(message);
                                baos.close();
                                is.close();
                            }
                        } catch (Exception e) {
                            Log.d("zz", e.toString());
                        }

                    }
                }).start();
            }
        });
            }

        }
