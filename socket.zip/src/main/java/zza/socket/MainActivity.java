package zza.socket;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class MainActivity extends AppCompatActivity {
    private Button button1,button2;
    TextView textView;
    EditText editText1,editText2,editText3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ID();
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                connect();
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                send();
            }
        });

    }
    Socket socket=null;
    BufferedReader bufferedReader=null;
    BufferedWriter bufferedWriter=null;
    public void connect(){

        AsyncTask<Void,String,Void> asyncTask =new AsyncTask<Void, String, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                try{
                socket =new Socket(editText2.getText().toString().trim(),Integer.parseInt(editText1.getText().toString().trim()));
                bufferedReader =new BufferedReader(new InputStreamReader(socket.getInputStream()));
                bufferedWriter =new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
                publishProgress("success");
                } catch (UnknownHostException e1) {
                    publishProgress("low");
                }catch (IOException e){
                    publishProgress("low");
                }
                try{
                    String data =null;
                    while((data=bufferedReader.readLine())!=null){
                        publishProgress(data);
                    }
                }catch (IOException e){
                    e.printStackTrace();
                }
                return null;
            }

            @Override
            protected void onProgressUpdate(String... values) {
                if(values[0].equals("success"))
                {
                    Toast.makeText(MainActivity.this, "连接成功", Toast.LENGTH_SHORT).show();

                }
                if(values[0].equals("low"))
                {
                    Toast.makeText(MainActivity.this, "连接失败", Toast.LENGTH_SHORT).show();
                }
                textView.append("别人说："+values[0]+"\n");
                super.onProgressUpdate(values);
            }
        };
        asyncTask.execute();
    }
    public void send(){
        try {
            textView.append("我说:"+editText3.getText().toString().trim()+"\n");
//            bufferedWriter.write(Data, 0, Data.length());
            bufferedWriter.write(


                    editText3.getText().toString().trim()+"\n");
            bufferedWriter.flush();
            editText3.setText(" ");

        }catch (IOException e){
            e.printStackTrace();
        }
    }
    public  void ID(){
        button1 =(Button)findViewById(R.id.connect);
        button2=(Button)findViewById(R.id.send);
        textView =(TextView)findViewById(R.id.tv);
        editText1 =(EditText)findViewById(R.id.com);
        editText2=(EditText)findViewById(R.id.ip);
        editText3=(EditText)findViewById(R.id.editText);
    }
}
